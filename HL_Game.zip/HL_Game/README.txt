Study Details:
This study aims to evaluate the use of procedural generation of sound effects and involves playing the included game segment five times over, filling out a form after each time.
No data is collected by the game application, only data entered and submitted via the provided form will be recorded.
You must provide a memorable phrase as an identifier for this provided data which will be stored strictly for the purposes of this research.
You may withdraw from this study at any point, and any associated data will be discarded immediately.
If you wish to withdraw mid participation you may safely exit the form without submitting as no responses are not recorded if not completed and submitted.
If you wish to withdraw after you have completed and submitted your responses please contact the listed email address, stating that you wish to withdraw your participation and provide your memorable phrase so that your data may be identified to be removed.

Particpation Instructions:
1. Full read through this file and open the form: https://forms.gle/gvr2yyNiwZWPqvzm6
2. Ensure that you understand the purpose and nature of this study and how your data will be treated.
3. Download and unzip the game
4. Launch ProjectGame.exe
5. Read the controls and click Play
6. Pause the game by pressing Tab or P
7. Move the SoundKey slider to the appropriate value
8. Shoot all the target enemies to fulfill the objective
9. When the Test Complete screen appears, return to the form and fill out a section
10. Return to the game and select Play Again.
11. Repeat steps 5 through 10 until the form is completed
12. Ensure that you have recorded your memorable phrase and submitted the form
13. You may now exit the game by pressing ESC during gameplay or selecting Exit from the main menu

Contact: Harry Lack 15591613@students.lincoln.ac.uk